fkt = [{'Name': 'SONY Cyber-shot DSC-RX100M3  (20.1 MP, 2.9 Optical Zoom, 44x Digital Zoom, Black)', 'Price': '₹50,990', 'Rating': '4.4', 'Reviews': ['The camera is a great an camera and can take great shots. But, frankly its not worth 50k and one should try to buy a dslr instead.', "It's a compact yet powerful camera. But the problem is that being few years old means it's lagging behind latest mobile devices and latest compact point and shoot cameras in terms of speed and features. This one is definitely slower and low light performance is not as much as expected. It struggles while taking macro shots as well as while shooting moving objects. But overall photo quality feels natural and close to real scene. Also it has different modes that can help you get ideal shooting ...\nREAD MORE", 'One of the best point and shoot camera available in the market. Packing was good as well as the condition was new.', '', '', '', '', '', '', ''], 'Product Link': 'https://www.flipkart.com/sony-cyber-shot-dsc-rx100m3/p/itmdxm2mjckzhgay?pid=CAMDXM2JZKP4HBYF&lid=LSTCAMDXM2JZKP4HBYFTURZ2A&marketplace=FLIPKART&q=sony+camera&store=jek%2Fp31&srno=s_1_1&otracker=search&iid=c066d3dd-8888-45cc-91b3-a600e5819faa.CAMDXM2JZKP4HBYF.SEARCH&ssid=vd7ctlwna80000001687681138402&qH=30ab055ab2a622fd', 'Image': 'https://rukminim1.flixcart.com/image/416/416/camera/b/y/f/sony-dsc-rx100m3-original-imadxm5yfrhcbeaz.jpeg?q=70'}]
# print(fkt[0]['Reviews'])



fkt[0]['Reviews']= "Summary"

print(fkt)
